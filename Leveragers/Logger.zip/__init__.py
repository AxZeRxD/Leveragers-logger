from .uwulogger import Leveragers

log = Leveragers()
